#!/usr/bin/env bash
set -euo pipefail

ROOTDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOTDIR"

echo "[1/4] Checking Eigen submodule files"
if [[ "${SKIP_SUBMODULE_CHECK:-0}" != "1" ]]; then
  eigen_local="$ROOTDIR/include/eigen3/Eigen/Dense"
  eigen_sys_candidates=(
    "/usr/include/eigen3/Eigen/Dense"
    "/usr/local/include/eigen3/Eigen/Dense"
    "/opt/homebrew/include/eigen3/Eigen/Dense"
  )

  eigen_path=""
  if [[ -f "$eigen_local" ]]; then
    eigen_path="$eigen_local"
  else
    for p in "${eigen_sys_candidates[@]}"; do
      if [[ -f "$p" ]]; then
        eigen_path="$p"
        break
      fi
    done
  fi

  if [[ -n "$eigen_path" ]]; then
    echo "Found Eigen headers: $eigen_path"
  else
    if [[ "${CI:-}" == "true" || "${REQUIRE_EIGEN:-0}" == "1" ]]; then
      echo "ERROR: Eigen headers not found in submodule or system include paths."
      echo "Fix options:"
      echo "  1) git submodule update --init --recursive"
      echo "  2) install system Eigen headers (e.g. libeigen3-dev)"
      exit 1
    fi
    echo "WARN: Eigen headers not found; skipping strict Eigen check outside CI."
  fi
else
  echo "SKIP_SUBMODULE_CHECK=1, skipping Eigen submodule check"
fi

echo "[2/4] Python bytecode check"
python3 -m compileall python-package/pycasso

echo "[3/4] Python lint check"
python3 -m pyflakes \
  python-package/pycasso/core.py \
  python-package/pycasso/libpath.py \
  python-package/pycasso/__init__.py \
  python-package/setup_common.py \
  python-package/setup.py \
  python-package/setup-pip.py

echo "[4/4] R syntax parse check"
Rscript -e "files <- list.files('R-package/R', full.names=TRUE); for (f in files) {parse(file=f); cat('OK', f, '\n')}"

echo "All quality checks passed"
