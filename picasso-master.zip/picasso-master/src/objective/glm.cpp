#include <picasso/objective.hpp>

namespace picasso {

GLMObjective::GLMObjective(const double *xmat, const double *y, int n, int d,
                           bool include_intercept)
    : ObjFunction(xmat, y, n, d) {
  (void)include_intercept;
  a = 0.0;
  g = 0.0;

  p.resize(n);
  w.resize(n);
  r.resize(n);

  wXX.resize(d);
}

double GLMObjective::coordinate_descent(RegFunction *regfunc, int idx) {
  g = 0.0;
  a = 0.0;

  // g = (<wXX, model_param.beta> + <r, X>)/n
  // a = sum(wXX)/n
  Eigen::ArrayXd wXX = w * X.col(idx) * X.col(idx);
  a = wXX.sum() / n;
  if (a <= 0.0) return model_param.beta[idx];

  g = (model_param.beta[idx] * wXX + r * X.col(idx)).sum()/n;

  double tmp;
  tmp = model_param.beta[idx];
  model_param.beta[idx] = regfunc->threshold(g) / a;

  tmp = model_param.beta[idx] - tmp;
  if (fabs(tmp) > 1e-8) {
    // Xb += delta*X[idx*n]
    Xb = Xb + tmp * X.col(idx);

    // r -= delta*w*X
    r = r - tmp * w * X.col(idx);
  }
  return (model_param.beta[idx]);
}

void GLMObjective::intercept_update() {
  if (sum_w <= 0.0) return;
  double sum_r = r.sum();
  const double delta = sum_r / sum_w;
  model_param.intercept += delta;
  r = r - delta * w;
  sum_r = 0;
}

void GLMObjective::update_gradient(int idx) {
  Eigen::ArrayXd tmp = (Y - p) * X.col(idx) / n;
  gr[idx] = tmp.sum();
}

double GLMObjective::get_local_change(double old, int idx) {
  if (idx >= 0) {
    double tmp = old - model_param.beta[idx];
    return ((w*X.col(idx)*X.col(idx)).sum() * tmp * tmp / (2 * n));
  } else {
    double tmp = old - model_param.intercept;
    return (sum_w * tmp * tmp / (2 * n));
  }
}

LogisticObjective::LogisticObjective(const double *xmat, const double *y, int n,
                                     int d, bool include_intercept)
    : GLMObjective(xmat, y, n, d, include_intercept) {
  if (include_intercept) {
    double avr_y = Y.sum() / n;
    const double eps = 1e-8;
    if (avr_y < eps) avr_y = eps;
    if (avr_y > 1.0 - eps) avr_y = 1.0 - eps;
    model_param.intercept = log(avr_y / (1 - avr_y));
  }

  update_auxiliary();
  for (int i = 0; i < d; i++) update_gradient(i);

  deviance = fabs(eval());
};

void LogisticObjective::update_auxiliary() {
  p = -model_param.intercept - Xb;
  p = p.exp();
  p = 1.0 / (1.0 + p);
  r = Y - p;

  w = p * (1 - p);
  sum_w = w.sum();
}

double LogisticObjective::eval() {
  double v = 0.0;
  for (int i = 0; i < n; i++) v -= Y[i] * (model_param.intercept + Xb[i]);

  for (int i = 0; i < n; i++)
    if (p[i] > 1e-8) v -= (log(p[i]) - model_param.intercept - Xb[i]);

  return (v / n);
}

PoissonObjective::PoissonObjective(const double *xmat, const double *y, int n,
                                   int d, bool include_intercept)
    : GLMObjective(xmat, y, n, d, include_intercept) {
  if (include_intercept) {
    double avr_y = Y.sum() / n;
    if (avr_y < 1e-8) avr_y = 1e-8;
    model_param.intercept = log(avr_y);
  }

  update_auxiliary();
  for (int i = 0; i < d; i++) update_gradient(i);

  deviance = fabs(eval());
};

void PoissonObjective::update_auxiliary() {
  Eigen::ArrayXd eta = model_param.intercept + Xb;
  p = eta.max(-50.0).min(50.0).exp();
  r = Y - p;
  w = p;
  sum_w = w.sum();
}

double PoissonObjective::eval() {
  double v = 0.0;
  for (int i = 0; i < n; i++)
    v = v + p[i] - Y[i] * (model_param.intercept + Xb[i]);
  return (v / n);
}

}  // namespace picasso
