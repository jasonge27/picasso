#include <stddef.h>
#include <R_ext/Rdynload.h>

extern void picasso_logit_solver(double *, double *, int *, int *, double *,
                                 int *, double *, int *, double *, int *, int *,
                                 double *, double *, int *, int *, double *);
extern void picasso_sqrt_lasso_solver(double *, double *, int *, int *, double *,
                                      int *, double *, int *, double *, int *,
                                      int *, double *, double *, int *, int *,
                                      double *);
extern void picasso_poisson_solver(double *, double *, int *, int *, double *,
                                   int *, double *, int *, double *, int *,
                                   int *, double *, double *, int *, int *,
                                   double *);
extern void picasso_gaussian_cov(double *, double *, int *, int *, double *,
                                 int *, double *, int *, double *, int *, int *,
                                 double *, double *, int *, int *, double *);
extern void picasso_gaussian_naive(double *, double *, int *, int *, double *,
                                   int *, double *, int *, double *, int *,
                                   int *, double *, double *, int *, int *,
                                   double *);
extern void standardize_design(double *, double *, double *, double *, int *,
                               int *);

static const R_CMethodDef CEntries[] = {
    {"picasso_logit_solver", (DL_FUNC)&picasso_logit_solver, 16},
    {"picasso_sqrt_lasso_solver", (DL_FUNC)&picasso_sqrt_lasso_solver, 16},
    {"picasso_poisson_solver", (DL_FUNC)&picasso_poisson_solver, 16},
    {"picasso_gaussian_cov", (DL_FUNC)&picasso_gaussian_cov, 16},
    {"picasso_gaussian_naive", (DL_FUNC)&picasso_gaussian_naive, 16},
    {"standardize_design", (DL_FUNC)&standardize_design, 6},
    {NULL, NULL, 0}};

void R_init_picasso(DllInfo *dll) {
  R_registerRoutines(dll, CEntries, NULL, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
