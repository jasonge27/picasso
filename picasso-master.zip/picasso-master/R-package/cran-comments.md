## Test environments

* local macOS (arm64), R 4.4.0

## R CMD check results

* `R CMD check --as-cran picasso_1.1.1.tar.gz`

No `ERROR`s from package code.

Local run includes environment-specific notes/warnings:

1. Internet access is disabled in this environment, so CRAN incoming checks cannot query CRAN/Bioconductor indices.
2. Installed `MASS`/`Matrix` were built under a patched R minor version (`4.4.1`) while the checker is `4.4.0`.
3. HTML validation notes are produced by the local validator for generated help HTML5 tags.

## Changes in this update

* Updated metadata (`Version: 1.2`, `Date`, `R (>= 3.5.0)`).
* Added missing namespace import for `plogis`.
* Added native routine registration (`src/init.c`) and disabled dynamic symbol lookup.
* Made `src/Makevars` portable for CRAN checks (removed non-portable optimization flags/GNU make extensions).
* Fixed packaged data/documentation consistency for `eyedata`.
