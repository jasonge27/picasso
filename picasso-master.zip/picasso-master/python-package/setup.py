# pylint: disable=invalid-name, exec-used
"""Setup picasso package."""
from __future__ import absolute_import
import os
from setuptools import setup

from setup_common import build_setup_kwargs, prepare_libraries

CURRENT_DIR = os.path.dirname(__file__)

prepare_libraries(CURRENT_DIR, [os.path.join(CURRENT_DIR, '../lib/')])
setup(**build_setup_kwargs(CURRENT_DIR))
