.. pycasso documentation master file, created by
   sphinx-quickstart on Sun Sep 24 01:54:19 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pycasso's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   README
   pycasso


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
