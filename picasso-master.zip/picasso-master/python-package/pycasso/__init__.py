# coding: utf-8
"""
PICASSO: Penalized Generalized Linear Model Solver - Unleash the Power of Non-convex Penalty

:Author: Jason Ge, Haoming Jiang
:Maintainer: Haoming Jiang <jianghm@gatech.edu>

"""

from __future__ import absolute_import

import os

from .core import Solver

def test():
    """Show welcome information."""
    current_file = os.path.dirname(__file__)
    with open(os.path.join(current_file, 'VERSION'), encoding='utf-8') as f:
        version = f.read().strip()
    print(r"Picasso has been successfully imported!")
    print(r"Version: " + version)

__all__ = ["core", "Solver", "test"]
