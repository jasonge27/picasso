# pylint: disable=invalid-name, exec-used
"""Setup picasso package."""
from __future__ import absolute_import
import os
import subprocess
from setuptools import setup

from setup_common import build_setup_kwargs, prepare_libraries

CURRENT_DIR = os.path.dirname(__file__)

# complie c code
if os.name != 'nt':
    src_dir = os.path.join(CURRENT_DIR, 'pycasso/src')
    subprocess.check_call(['make', 'clean'], cwd=src_dir)
    subprocess.check_call(['make', 'dylib'], cwd=src_dir)
else:
    raise RuntimeError('Windows users please install from source')

prepare_libraries(CURRENT_DIR, [os.path.join(CURRENT_DIR, './pycasso/src/lib/')])
setup(**build_setup_kwargs(CURRENT_DIR))
