# pylint: disable=invalid-name, exec-used
"""Shared setup helpers for pycasso packaging scripts."""
from __future__ import absolute_import

import os
import shutil
import sys

from setuptools import find_packages


INSTALL_REQUIRES = [
    'numpy',
    'scipy',
]

CLASSIFIERS = [
    'Development Status :: 3 - Alpha',
    'Intended Audience :: Developers',
    'Intended Audience :: Science/Research',
    'Topic :: Scientific/Engineering :: Artificial Intelligence',
    'Topic :: Scientific/Engineering :: Mathematics',
    'Programming Language :: Python :: 3 :: Only',
    'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
]


def _candidate_library_paths(libdir_candidate):
    if sys.platform == 'win32':
        paths = [os.path.join(p, 'picasso.dll') for p in libdir_candidate]
        return paths + [os.path.join(p, 'libpicasso.so') for p in libdir_candidate]
    if sys.platform.startswith('linux'):
        return [os.path.join(p, 'libpicasso.so') for p in libdir_candidate]
    if sys.platform == 'darwin':
        paths = [os.path.join(p, 'libpicasso.so') for p in libdir_candidate]
        return paths + [os.path.join(p, 'libpicasso.dylib') for p in libdir_candidate]
    return []


def copy_libraries(current_dir, libdir_candidate):
    libcand_path = _candidate_library_paths(libdir_candidate)
    lib_path = [p for p in libcand_path if os.path.exists(p) and os.path.isfile(p)]

    target_lib_dir = os.path.join(current_dir, './pycasso/lib/')
    os.makedirs(target_lib_dir, exist_ok=True)
    for lib_file in lib_path:
        shutil.copy(lib_file, target_lib_dir)

    return lib_path


def validate_library_path(current_dir):
    # We can not import `picasso.libpath` in setup.py directly, since it may
    # import package modules before install_requires is resolved.
    libpath_py = os.path.join(current_dir, 'pycasso/libpath.py')
    libpath = {'__file__': libpath_py}
    with open(libpath_py, "rb") as f:
        exec(compile(f.read(), libpath_py, 'exec'), libpath, libpath)

    lib_paths = [
        os.path.relpath(libfile, current_dir) for libfile in libpath['find_lib_path']()
    ]
    if not lib_paths:
        raise RuntimeError("libpicasso does not exists")
    print("libpicasso already exists: %s" % lib_paths)
    return lib_paths


def prepare_libraries(current_dir, libdir_candidate):
    copy_libraries(current_dir, libdir_candidate)
    return validate_library_path(current_dir)


def read_version_and_readme(current_dir):
    version_path = os.path.join(current_dir, 'pycasso/VERSION')
    with open(version_path, encoding='utf-8') as f:
        version = f.read().strip()
    with open(os.path.join(current_dir, 'README.rst'), encoding='utf-8') as f:
        readme = f.read()
    return version, readme


def build_setup_kwargs(current_dir):
    version, readme = read_version_and_readme(current_dir)
    return {
        'name': 'pycasso',
        'version': version,
        'description': "Picasso Python Package",
        'long_description': readme,
        'install_requires': INSTALL_REQUIRES,
        'maintainer': 'Haoming Jiang',
        'maintainer_email': 'jianghm.ustc@gmail.com',
        'zip_safe': False,
        'packages': find_packages(),
        'include_package_data': True,
        'license': 'GPL-3.0',
        'classifiers': CLASSIFIERS,
        'url': 'https://hmjianggatech.github.io/picasso/',
    }
